﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CabinetMedical_AilioaeiSorinaElena1051
{
    public class Reteta
    {
        private string[] NumeMedicamente { get; set; }
        private int[] NrPastile { get; set; }


        public Reteta()
        {
            this.NumeMedicamente = null;
            this.NrPastile = null;
        }
        public Reteta(string[] medicamente, int[] nrPastile)
        {
            if (medicamente != null)
            {
                this.NumeMedicamente = new string[medicamente.Length];
                for(int i = 0; i < medicamente.Length; i++)
                {
                    NumeMedicamente[i] = medicamente[i];
                }
            }
            if (nrPastile != null)
            {
                this.NrPastile = new int[nrPastile.Length];
                for (int i = 0; i < nrPastile.Length; i++)
                {
                    NrPastile[i] = nrPastile[i];
                }
            }
        }

        public override string ToString()
        {
            string result="";
            result += ", reteta: ";
            if(NumeMedicamente != null && NrPastile != null)
            {
                for (int i = 0; i < NumeMedicamente.Length; i++)
                    result += NumeMedicamente[i] + " - " + NrPastile[i] + ", ";
            }
 
            return result;
        }
    }
}
