﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CabinetMedical_AilioaeiSorinaElena1051
{
    public partial class Form5 : Form
    {
        List<Medic> listaMedici = new List<Medic>();
        public Form5( List<Medic> lista)
        {
            InitializeComponent();
            listaMedici = lista ?? new List<Medic>(); ;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (tbIdMedic.Text == "") errorProvider1.SetError(tbIdMedic, "Introduceti id-ul medicului!");
            else if (tbNumeMedic.Text == "") errorProvider1.SetError(tbNumeMedic, "Introduceti numele medicului!");
            else if (comboBox2.SelectedItem== null) errorProvider1.SetError(comboBox2, "Introduceti specializarea medicului!");
            else
                try
                {
                    int idMedic = int.Parse(tbIdMedic.Text);
                    string numeMedic = tbNumeMedic.Text;
                    string specializare = comboBox2.Text;
                    Medic medic = new Medic(idMedic, numeMedic, specializare);
                    listaMedici.Add(medic);
                    MessageBox.Show("Medicul a fost inregistrat!");

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    tbIdMedic.Clear();
                    tbNumeMedic.Clear();
                    comboBox2.SelectedIndex = -1;
                    errorProvider1.Clear();
                }
        }
        private void btnCANCEL_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void tbIdMedic_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
                e.Handled = true;
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            label2.Hide();
            tbMedici.Hide();
        }
        private void afisareMediciToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label2.Show();
            tbMedici.Show();
            foreach(Medic medic in listaMedici)
            {
               tbMedici.Text+= medic.ToString() + Environment.NewLine;
            }
        }

    }
}