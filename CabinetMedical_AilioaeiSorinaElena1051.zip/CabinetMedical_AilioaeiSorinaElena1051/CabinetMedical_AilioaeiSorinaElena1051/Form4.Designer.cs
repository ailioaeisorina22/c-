﻿
namespace CabinetMedical_AilioaeiSorinaElena1051
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblp = new System.Windows.Forms.Label();
            this.tbPac = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.backToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salveazaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.citesteDinFisierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAfisPac = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblp
            // 
            this.lblp.AutoSize = true;
            this.lblp.BackColor = System.Drawing.Color.Transparent;
            this.lblp.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblp.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblp.Location = new System.Drawing.Point(3, 39);
            this.lblp.Name = "lblp";
            this.lblp.Size = new System.Drawing.Size(274, 69);
            this.lblp.TabIndex = 0;
            this.lblp.Text = "Pacienti";
            // 
            // tbPac
            // 
            this.tbPac.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tbPac.Font = new System.Drawing.Font("Courier New", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPac.Location = new System.Drawing.Point(0, 207);
            this.tbPac.Multiline = true;
            this.tbPac.Name = "tbPac";
            this.tbPac.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbPac.Size = new System.Drawing.Size(962, 296);
            this.tbPac.TabIndex = 1;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backToolStripMenuItem,
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(962, 30);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // backToolStripMenuItem
            // 
            this.backToolStripMenuItem.Font = new System.Drawing.Font("Courier New", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backToolStripMenuItem.Name = "backToolStripMenuItem";
            this.backToolStripMenuItem.Size = new System.Drawing.Size(63, 26);
            this.backToolStripMenuItem.Text = "Back";
            this.backToolStripMenuItem.Click += new System.EventHandler(this.backToolStripMenuItem_Click);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salveazaToolStripMenuItem,
            this.citesteDinFisierToolStripMenuItem});
            this.fileToolStripMenuItem.Font = new System.Drawing.Font("Courier New", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(63, 26);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // salveazaToolStripMenuItem
            // 
            this.salveazaToolStripMenuItem.Name = "salveazaToolStripMenuItem";
            this.salveazaToolStripMenuItem.Size = new System.Drawing.Size(272, 26);
            this.salveazaToolStripMenuItem.Text = "Salveaza";
            this.salveazaToolStripMenuItem.Click += new System.EventHandler(this.salveazaToolStripMenuItem_Click);
            // 
            // citesteDinFisierToolStripMenuItem
            // 
            this.citesteDinFisierToolStripMenuItem.Name = "citesteDinFisierToolStripMenuItem";
            this.citesteDinFisierToolStripMenuItem.Size = new System.Drawing.Size(272, 26);
            this.citesteDinFisierToolStripMenuItem.Text = "Citeste din fisier";
            this.citesteDinFisierToolStripMenuItem.Click += new System.EventHandler(this.citesteDinFisierToolStripMenuItem_Click);
            // 
            // btnAfisPac
            // 
            this.btnAfisPac.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnAfisPac.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAfisPac.ForeColor = System.Drawing.Color.CadetBlue;
            this.btnAfisPac.Location = new System.Drawing.Point(27, 129);
            this.btnAfisPac.Name = "btnAfisPac";
            this.btnAfisPac.Size = new System.Drawing.Size(193, 72);
            this.btnAfisPac.TabIndex = 4;
            this.btnAfisPac.Text = "Afiseaza pacienti";
            this.btnAfisPac.UseVisualStyleBackColor = false;
            this.btnAfisPac.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CabinetMedical_AilioaeiSorinaElena1051.Properties.Resources.pacienti1;
            this.pictureBox1.Location = new System.Drawing.Point(303, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(659, 230);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(962, 503);
            this.Controls.Add(this.btnAfisPac);
            this.Controls.Add(this.tbPac);
            this.Controls.Add(this.lblp);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.pictureBox1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form4";
            this.Text = "Detalii Pacienti";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblp;
        private System.Windows.Forms.TextBox tbPac;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem backToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salveazaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem citesteDinFisierToolStripMenuItem;
        private System.Windows.Forms.Button btnAfisPac;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}