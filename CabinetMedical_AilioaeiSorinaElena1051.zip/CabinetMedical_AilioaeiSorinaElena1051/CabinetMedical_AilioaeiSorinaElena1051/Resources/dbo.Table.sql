﻿CREATE TABLE Pacienti (
    IdPacient INT PRIMARY KEY,
    NumePacient NVARCHAR(50),
    Varsta INT,
    Diagnostic NVARCHAR(100),
    ZileSpitalizare INT
);