﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CabinetMedical_AilioaeiSorinaElena1051
{
   public class Pacient
    {
        public int idPacient { get; set; }
        public string Nume { get; set; }
        public int Varsta { get; set; }
        public string Diagnostic { get; set; }
        public int ZileSpitalizare { get; set; }
        public Medic Medic { get; set; }
        public Reteta Reteta { get; set; }
        public Pacient()
        {
            this.idPacient = 0;
            this.Nume = "anonim";
            this.Varsta = 0;
            this.Diagnostic = "necunoscut";
            this.Medic = new Medic();
            this.Reteta = new Reteta();

        }
        public Pacient(int id, string nume, int varsta, string diagnostic, int zileSpitalizare, Medic medic, Reteta reteta)
        {
            this.idPacient = id;
            this.Nume = nume;
            this.Diagnostic = diagnostic;
            this.Varsta = varsta;
            this.ZileSpitalizare = zileSpitalizare;
            this.Medic = medic;
            this.Reteta = reteta;
        }
        public Pacient(int id, string nume, int varsta, string diagnostic, int zileSpitalizare)
        {
            this.idPacient = id;
            this.Nume = nume;
            this.Diagnostic = diagnostic;
            this.Varsta = varsta;
            this.ZileSpitalizare = zileSpitalizare; ;
        }
        public override string ToString()
        {
            string result = base.ToString();
            result =  "Pacientul cu id-ul: " + idPacient + ", numele: " + Nume + ", varsta: " + Varsta + ", diagnostic: " + Diagnostic +", zile spitalizare: "+ZileSpitalizare + " "+Medic.ToString()+" "+Reteta.ToString();
           
            return result;    
        }
    }
}
