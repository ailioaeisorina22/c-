﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CabinetMedical_AilioaeiSorinaElena1051
{
   public class Medic
    {
        public int Id { get; set; }
        public string Nume { get; set; }
        public string Specializare { get; set; }
        public Medic()
        {
            this.Id = 0;
            this.Nume = "anonim";
            this.Specializare = "necunoscut";
        }
        public Medic( int id, string nume, string specializare)
        {
            this.Id = id;
            this.Nume = nume;
            this.Specializare = specializare;
        }

        public override string ToString()
        {
           return "Id medic: "+Id+", Nume medic: " + Nume+ " , specializare: "+Specializare;
          
        }
    }
}
