﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CabinetMedical_AilioaeiSorinaElena1051
{
    public partial class Form4 : Form
    {
        List<Pacient> lista2 = new List<Pacient>();
        public Form4(List<Pacient> lista)
        {
            InitializeComponent();
            lista2 = lista;
        }

        private void backToolStripMenuItem_Click(object sender, EventArgs e)
        {  this.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            tbPac.Clear();
            foreach (Pacient p in lista2)
                tbPac.Text += p.ToString() + Environment.NewLine;
        }


        private void salveazaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "(*.txt)|*.txt";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(dlg.FileName);
                sw.WriteLine(tbPac.Text);
                sw.Close();
                tbPac.Clear();
            }
        }

        private void citesteDinFisierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "(*.txt)|*.txt";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                StreamReader sr = new StreamReader(dlg.FileName);
                tbPac.Text = sr.ReadToEnd();
                sr.Close();
            }
        }


        private void tbPac_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
