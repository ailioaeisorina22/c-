﻿
namespace CabinetMedical_AilioaeiSorinaElena1051
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCabinet = new System.Windows.Forms.Label();
            this.btnProg = new System.Windows.Forms.Button();
            this.btnDetalii = new System.Windows.Forms.Button();
            this.btnMedic = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCabinet
            // 
            this.lblCabinet.AutoSize = true;
            this.lblCabinet.BackColor = System.Drawing.Color.SeaGreen;
            this.lblCabinet.Font = new System.Drawing.Font("Broadway", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCabinet.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblCabinet.Location = new System.Drawing.Point(172, 38);
            this.lblCabinet.Name = "lblCabinet";
            this.lblCabinet.Size = new System.Drawing.Size(498, 55);
            this.lblCabinet.TabIndex = 0;
            this.lblCabinet.Text = "CABINET MEDICAL";
            // 
            // btnProg
            // 
            this.btnProg.BackColor = System.Drawing.Color.SeaGreen;
            this.btnProg.Font = new System.Drawing.Font("Cooper Black", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProg.ForeColor = System.Drawing.SystemColors.Control;
            this.btnProg.Location = new System.Drawing.Point(75, 157);
            this.btnProg.Name = "btnProg";
            this.btnProg.Size = new System.Drawing.Size(298, 68);
            this.btnProg.TabIndex = 2;
            this.btnProg.Text = "PROGRAMARE PACIENT";
            this.btnProg.UseVisualStyleBackColor = false;
            this.btnProg.Click += new System.EventHandler(this.btnProg_Click);
            // 
            // btnDetalii
            // 
            this.btnDetalii.BackColor = System.Drawing.Color.SeaGreen;
            this.btnDetalii.Font = new System.Drawing.Font("Cooper Black", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetalii.ForeColor = System.Drawing.SystemColors.Control;
            this.btnDetalii.Location = new System.Drawing.Point(75, 299);
            this.btnDetalii.Name = "btnDetalii";
            this.btnDetalii.Size = new System.Drawing.Size(298, 73);
            this.btnDetalii.TabIndex = 3;
            this.btnDetalii.Text = "DETALII PACIENTI";
            this.btnDetalii.UseVisualStyleBackColor = false;
            this.btnDetalii.Click += new System.EventHandler(this.btnDetalii_Click);
            // 
            // btnMedic
            // 
            this.btnMedic.BackColor = System.Drawing.Color.SeaGreen;
            this.btnMedic.Font = new System.Drawing.Font("Cooper Black", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedic.ForeColor = System.Drawing.SystemColors.Control;
            this.btnMedic.Location = new System.Drawing.Point(484, 299);
            this.btnMedic.Name = "btnMedic";
            this.btnMedic.Size = new System.Drawing.Size(288, 73);
            this.btnMedic.TabIndex = 5;
            this.btnMedic.Text = "STATISTICA MEDICI";
            this.btnMedic.UseVisualStyleBackColor = false;
            this.btnMedic.Click += new System.EventHandler(this.btnMedic_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CabinetMedical_AilioaeiSorinaElena1051.Properties.Resources.WhatsApp_Image_2024_05_26_at_00_40_51;
            this.pictureBox1.Location = new System.Drawing.Point(10, 96);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(819, 383);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SeaGreen;
            this.button1.Font = new System.Drawing.Font("Cooper Black", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.Control;
            this.button1.Location = new System.Drawing.Point(484, 157);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(288, 73);
            this.button1.TabIndex = 7;
            this.button1.Text = "ADAUGA MEDIC";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(844, 496);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnMedic);
            this.Controls.Add(this.btnDetalii);
            this.Controls.Add(this.btnProg);
            this.Controls.Add(this.lblCabinet);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Cabinet Medical - Meniu";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCabinet;
        private System.Windows.Forms.Button btnProg;
        private System.Windows.Forms.Button btnDetalii;
        private System.Windows.Forms.Button btnMedic;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
    }
}

