﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CabinetMedical_AilioaeiSorinaElena1051
{
    public partial class Form2 : Form
    {
        string[] ramuriMedicina = { "Stomatologie", "Chirurgie", "Urologie","Oftalmologie",  "Radiologie", "Imunologie","Cardiologie", "Pediatrie", "Neurologie", "Psihiatrie" };
        int[] nrDoctori = {3,2,2,4,5,2,4,6,3,6 };
        bool vb = false;
        int nr = 0;
        const int margine = 10;
        Color culoare = Color.SeaGreen;
        Color culoare2 = Color.DarkSlateGray;
        Font font = new Font(FontFamily.GenericSerif, 12, FontStyle.Bold);

        public Form2()
        {
            InitializeComponent();

            // Asocierea evenimentului Paint cu panoul
            panel1.Paint += new PaintEventHandler(Form2_Paint);
        }

        private void backToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void graficDateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ramuriMedicina != null && nrDoctori != null)
            {
                for(int i=0;i<ramuriMedicina.Length;i++)
                {
                    nr++;
                }
                vb = true;
                MessageBox.Show("Datele sunt disponibile!");
            }
            else
            {
                MessageBox.Show("Datele sunt indisponibile!");
            }
            panel1.Invalidate();
        }

        private void Form2_Paint(object sender, PaintEventArgs e)
        {
            if (vb == true)
            {
                Graphics g = e.Graphics;
                Rectangle rec = new Rectangle(this.ClientRectangle.X +margine, this.ClientRectangle.Y + 4* margine, this.ClientRectangle.Width - 2 * margine, this.ClientRectangle.Height - 10* margine);
                Pen pen = new Pen(Color.DarkSlateGray, 2);
                g.DrawRectangle(pen, rec);

                double latime = rec.Width / nr / 3;
                double distanta = (rec.Width - nr * latime) / (nr + 1);
                double vMax = nrDoctori.Max();

                Brush br = new SolidBrush(culoare);
                Brush br2 = new SolidBrush(culoare2);

                Rectangle[] recs = new Rectangle[nr];
                for (int i = 0; i < nr; i++)
                {
                    recs[i] = new Rectangle((int)(rec.Location.X + (i + 1) * distanta + i * latime),
                      (int)(rec.Location.Y + rec.Height - nrDoctori[i] / vMax * rec.Height + 2 * margine),
                      (int)latime,
                      (int)(nrDoctori[i] / vMax * rec.Height - 2 * margine));
                    g.DrawString(nrDoctori[i].ToString(), font, br, new Point((int)recs[i].Location.X, (int)recs[i].Location.Y - font.Height));
                    g.DrawString(ramuriMedicina[i].ToString(), font, br2, new Point((int)recs[i].Location.X, (int)recs[i].Location.Y -2*font.Height));
                }
                g.FillRectangles(br, recs);
            }
        }

        private void printeazaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += new PrintPageEventHandler(pdPrint);
            PrintPreviewDialog dlg = new PrintPreviewDialog();
            dlg.Document = pd;
            dlg.ShowDialog();
        }

        private void pdPrint(object sender, PrintPageEventArgs e)
        {
            if (vb == true)
            {
                Graphics g = e.Graphics;
                Rectangle rec = new Rectangle(e.PageBounds.X + margine, e.PageBounds.Y + 4 * margine, e.PageBounds.Width - 2 * margine, e.PageBounds.Height - 10 * margine);
                Pen pen = new Pen(Color.DarkSlateGray, 2);
                g.DrawRectangle(pen, rec);

                double latime = rec.Width / nr / 3;
                double distanta = (rec.Width - nr * latime) / (nr + 1);
                double vMax = nrDoctori.Max();

                Brush br = new SolidBrush(culoare);
                Brush br2 = new SolidBrush(culoare2);

                Rectangle[] recs = new Rectangle[nr];
                for (int i = 0; i < nr; i++)
                {
                    recs[i] = new Rectangle((int)(rec.Location.X + (i + 1) * distanta + i * latime),
                      (int)(rec.Location.Y + rec.Height - nrDoctori[i] / vMax * rec.Height + 2 * margine),
                      (int)latime,
                      (int)(nrDoctori[i] / vMax * rec.Height - 2 * margine));
                    g.DrawString(nrDoctori[i].ToString(), font, br, new Point((int)recs[i].Location.X, (int)recs[i].Location.Y - font.Height));
                    g.DrawString(ramuriMedicina[i].ToString(), font, br2, new Point((int)recs[i].Location.X, (int)recs[i].Location.Y - 2 * font.Height));
                }
                g.FillRectangles(br, recs);
            }
        }

    }
}
