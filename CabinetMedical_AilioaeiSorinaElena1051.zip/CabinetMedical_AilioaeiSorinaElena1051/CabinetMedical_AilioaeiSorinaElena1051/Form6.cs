﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CabinetMedical_AilioaeiSorinaElena1051
{
    

    public partial class Form6 : Form
    {
        private string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=Pacienti;Integrated Security=True";
        private List<Pacient> listaPacienti = new List<Pacient>();
        public Form6()
        {
            InitializeComponent();
            LoadPacientiFromDatabase();
        }
        private void LoadPacientiFromDatabase()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT IdPacient, NumePacient, Varsta, Diagnostic, ZileSpitalizare FROM Pacienti";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int idPacient = reader.GetInt32(0);
                                string numePacient = reader.GetString(1);
                                int varsta = reader.GetInt32(2);
                                string diagnostic = reader.GetString(3);
                                int zileSpitalizare = reader.GetInt32(4);

                                Pacient pacient = new Pacient(idPacient, numePacient, varsta, diagnostic, zileSpitalizare);
                                listaPacienti.Add(pacient);
                            }
                        }
                    }
                }
                dataGridView1.DataSource = listaPacienti;
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"SQL error: {ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
    
}
}
