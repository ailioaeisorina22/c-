﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CabinetMedical_AilioaeiSorinaElena1051
{
    public partial class Form3 : Form
    {
        Pacient p1 = new Pacient();
        List<Pacient> listaPacienti = new List<Pacient>();
        List<Medic> listaMedici = new List<Medic>();

        public Form3(List<Pacient> listaP, List<Medic> listaM)
        {
            InitializeComponent();
            this.listaPacienti = listaP;
            this.listaMedici = listaM;
        }

        private void btnOK_Click(object sender, EventArgs e)  
        {

            if (tbIdPacient.Text == "")
                errorProvider1.SetError(tbIdPacient, "Introduceti id-ul pacientului!");
            else if (tbNumePacient.Text == "") errorProvider1.SetError(tbNumePacient, "Introduceti numele pacientului!");
            else if (tbVarsta.Text == "") errorProvider1.SetError(tbVarsta, "Introduceti varsta pacientului!");
            else if (tbDiagnostic.Text == "") errorProvider1.SetError(tbDiagnostic, "Introduceti diagnosticul pacientului!");
            else if (tbZileSpitalizare.Text == "") errorProvider1.SetError(tbZileSpitalizare, "Introduceti zilele de spitalizare ale pacientului!");
            else if (comboBox1.SelectedItem == null) errorProvider1.SetError(comboBox1, "Introduceti medicul!");
            else if (tbMed.Text == "") errorProvider1.SetError(tbMed, "Introduceti medicamentele!");
            else if (tbCant.Text == "") errorProvider1.SetError(tbCant, "Introduceti cantitatea medicamentelor!");

            else
                try
                {
                    int idPacient = int.Parse(tbIdPacient.Text);
                    string numePacient = tbNumePacient.Text;
                    int varstaPacient = int.Parse(tbVarsta.Text);
                    string diagnostic = tbDiagnostic.Text;
                    int zileSpitalizare = int.Parse(tbZileSpitalizare.Text);
                    Medic medic = comboBox1.SelectedItem as Medic;

                    string[] medicamente = tbMed.Text.Split(',');
                    int[] cantitati = new int[medicamente.Length];
                    string[] strCantitati = tbCant.Text.Split(',');
                    for (int i = 0; i < strCantitati.Length; i++)
                    {
                        cantitati[i] = int.Parse(strCantitati[i]);
                    }
                    Reteta reteta = new Reteta(medicamente, cantitati);
                    p1 = new Pacient(idPacient, numePacient, varstaPacient, diagnostic, zileSpitalizare, medic, reteta);

                    listaPacienti.Add(p1);
                    MessageBox.Show("Pacientul a fost inregistrat!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                finally
                {
                    tbIdPacient.Clear();
                    tbNumePacient.Clear();
                    tbVarsta.Clear();
                    tbDiagnostic.Clear();
                    tbZileSpitalizare.Clear();
                    comboBox1.SelectedIndex = -1;
                    tbMed.Clear();
                    tbCant.Clear();
                    errorProvider1.Clear();
                }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void afisarePacientiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4(listaPacienti);
            form4.Show();
        }

        private void tbIdPacient_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void tbVarsta_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void tbIdMedic_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void retetaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Pacientul primeste o reteta ce contine numele pastilelor si cantitatea ce trebuie luata intr-o zi!");
        }

        private void tbZileSpitalizare_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
                e.Handled = true;

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            foreach (Medic medic in listaMedici)
            {
                comboBox1.Items.Add(medic.Nume);
            }
        }

        private void comboBox1_DropDown(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();  
            if (listaMedici == null || listaMedici.Count == 0)
            {
                MessageBox.Show("Nu exista medici angajati in cabinet! Adaugati prima data medicii!");
                this.Close();
                Form5 form5 = new Form5(listaMedici);
                form5.Show();
            }
            else
            {
                foreach (var medic in listaMedici)
                {
                    comboBox1.Items.Add(medic); 
                }
            }
        }

        private void pacientiDataBaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=Pacienti;Integrated Security=True";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query1 = "DELETE FROM Pacienti";
                    using (SqlCommand command1 = new SqlCommand(query1, connection))
                    {
                        command1.ExecuteNonQuery();
                    }

                    foreach (Pacient pacient in listaPacienti)
                    {
                        string query = "INSERT INTO Pacienti (IdPacient, NumePacient, Varsta, Diagnostic, ZileSpitalizare) VALUES (@IdPacient, @NumePacient, @Varsta, @Diagnostic, @ZileSpitalizare)";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@IdPacient", pacient.idPacient);
                            command.Parameters.AddWithValue("@NumePacient", pacient.Nume);
                            command.Parameters.AddWithValue("@Varsta", pacient.Varsta);
                            command.Parameters.AddWithValue("@Diagnostic", pacient.Diagnostic);
                            command.Parameters.AddWithValue("@ZileSpitalizare", pacient.ZileSpitalizare);
                            command.ExecuteNonQuery();
                        }
                    }
                    Form6 form6 = new Form6();
                    form6.Show();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"SQL error: {ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

    }
}

